<?php
include(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_flexicontent'.DS.'views'.DS.'filemanager'.DS.'tmpl'.DS.'default.php');