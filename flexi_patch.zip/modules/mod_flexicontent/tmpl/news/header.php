<div id="<?php echo $module->module . '_' . $module->id; ?>">

<?php
