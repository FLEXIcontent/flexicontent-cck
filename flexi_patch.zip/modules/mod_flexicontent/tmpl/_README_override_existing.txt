You can create templates inside current folder


-- But you can in Joomla template folder too

To override a template file of the module inside your Joomla template (e.g.):
  news.php,  carousel.php,  select.php,  default.php,  ETC

copy the above to your Joomla template folder
   /templates/JOOMLA_TEMPLATE_NAME/html/mod_flexicontent/tmpl/news.php
   /templates/JOOMLA_TEMPLATE_NAME/html/mod_flexicontent/tmpl/carousel.php
   /templates/JOOMLA_TEMPLATE_NAME/html/mod_flexicontent/tmpl/select.php
   /templates/JOOMLA_TEMPLATE_NAME/html/mod_flexicontent/tmpl/default.php

and override them with customized code




TO also override module HEADER and FOOTER for this template, e.g.
  /tmpl/news/header.php
  /tmpl/news/footer.php
  
copy them to your Joomla template folder as:
   /templates/JOOMLA_TEMPLATE_NAME/html/mod_flexicontent/tmpl/news/header.php
   /templates/JOOMLA_TEMPLATE_NAME/html/mod_flexicontent/tmpl/news/footer.php

and override them with customized code
