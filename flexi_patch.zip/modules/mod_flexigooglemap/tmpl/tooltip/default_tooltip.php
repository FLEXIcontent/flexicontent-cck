<?php
echo 'Default tooltip';