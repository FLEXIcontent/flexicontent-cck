# mod_flexigooglemap
====================
Module to display all items in category like a marker with address-internation field (flexicontent version 3.0.13+)

## Module FLEXIgooglemap features

FLEXIContent **Google map module**

-**2 modes**
 - Fixed category (list all item in category and subcategories)
 - Current category (list all item in category **display**) => **COMPATIBLE WITH FLEXIcontent filter**

-**Options**
 - Clustering marker
 - API key
 - Custom image for marker point
 - Letter mode for marker point
 - Map type
 - Map responsive
 - Custom infos windows (link, target, itemid, adress, link to direction)
 - Flexicontent field replacement (coming soon)
