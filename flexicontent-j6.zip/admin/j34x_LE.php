<?php

namespace Joomla\String;

class StringHelper extends String
{
}